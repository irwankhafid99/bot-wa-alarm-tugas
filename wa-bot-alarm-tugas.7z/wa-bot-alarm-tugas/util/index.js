exports.color = require('./color')
exports.options = require('./options')