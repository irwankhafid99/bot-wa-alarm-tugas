# WhatsApp Bot Alarm Tugas

Just an practice for my project.

## Installation

Clone repo or Download zip file, and then do this.

```node.js
npm i
```
Run NPM.

```node.js
npm start
```


## Thanks To
**[https://github.com/open-wa/wa-automate-nodejs](https://github.com/open-wa/wa-automate-nodejs)**.

## License
[MIT](https://choosealicense.com/licenses/mit/)